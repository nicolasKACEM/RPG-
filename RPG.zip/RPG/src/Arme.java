
public class Arme extends Equipement {

   
    
    
    
    public Arme() {
		 
		 super();
	 }

    
    public Arme(int maniabilite, int impact,int x,int y, String nom){

        super(0,0,maniabilite,impact,nom);
      

    }

    
   
    
}	