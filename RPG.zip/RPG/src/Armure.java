
public class Armure extends Equipement{


	 
	
	 
	 
	 public Armure() {
		 
		 super();
	 }
	 
	public Armure(int encombrement, int solidite,int x,int y,String nom){

        super(encombrement,solidite,0,0,nom);
        
	}
	
	

   
}