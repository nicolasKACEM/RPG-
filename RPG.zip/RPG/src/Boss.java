
public class Boss extends Monstre {

	Equipement loot;
	
	public Boss(int initiative, int attaque,int esquive,int defense, int degats, int PV, int posX,int posY,Equipement e) {
		
		super(initiative,  attaque,esquive,defense, degats,  PV,  posX, posY,"B");
		loot=e;
	}
	
	public Equipement getLoot() {
		
		return this.loot;
	}

}
