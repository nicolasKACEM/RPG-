	
	public class Carte {
	
		String tab[][] = new String[25][30];//une carte de 25 par 30
		
		
		
		public void CreerCarte() {
			
			
			for(int y=0;y<30;y++) {
				
				for(int x=0;x<25;x++) {
					
					tab[x][y]=" ";
					
					if(y==0||y==29||x==0||x==24)
						tab[x][y]="&"; //on fait les bordures de la map
				}
				
				
			}
					
	
			
		}		
		
		public void retirerObjet(Equipement a) {
			
			
			tab[a.getPosX()][a.getPosY()]=" "; 
			
			
		}
		
		public void anciennePositionMob(Monstre a) {
			
			
			tab[a.getPosX()][a.getPosY()]=" ";//lorsque le PNJ bouge ou meurt on met rend son ancienne position vide 
			
			
		}
		public void nouvellePositionMob(Monstre a) {
			
			tab[a.getPosX()][a.getPosY()]=a.getSymb();//on affiche le symbole du joueur sur la carte
			
		}
		
		public void anciennePositionJoueur(Joueur a) {
			
			
			tab[a.getPosX()][a.getPosY()]=" ";//lorsque le joueur bouge on met rend son ancienne position vide 
			
			
		}
		
		
		public boolean posDiffMur(int x, int y) {
			
			if(tab[x][y]!= "&")//pour savoir si la position donné est un mur
				return true;
			
			return false;
						
			
		}
		
		public boolean posDiffMonstre(int x, int y) {
			
			if(tab[x][y]!= "M" && tab[x][y]!= "B" && tab[x][y]!= "�"&& tab[x][y]!= "1"&& tab[x][y]!= "2")//pour savoir si la position donné est un pnj
				return true;
			
			return false;
						
			
		}
		
		public void nouvellePositionJoueur(Joueur a) {
			
			tab[a.getPosX()][a.getPosY()]=a.getSymb();//on affiche le symbole du joueur sur la carte
			
		}
		
		public void addMur(int x,int y) {
			
			
			this.tab[x][y]="&";//on ajoute un mur a cette position 
			
			
			
		}
		
		
		
		public void  afficher() {//on affiche la map
			
			for(int y = 0; y<30;y++){
				
				for(int x=0;x<25;x++) {
					
					System.out.print(tab[x][y]);
					
					if(x==24)
						System.out.print('\n');
				}
				
				
			}
				
		}
		
		
		public void ajouterMob(Monstre a) {
			
			
			tab[a.getPosX()][a.getPosY()]=a.getSymb();//on ajoute le pnj sur la carte
			
			
		}
		

		public void ajouterMarchand(Marchand a) {
			
			
			tab[a.getPosX()][a.getPosY()]=a.getSymb();//on ajoute le pnj sur la carte
			
			
		}
		
		public void ajouterStuff(Equipement a) {
			
			
			tab[a.getPosX()][a.getPosY()]=a.getSymb();//on ajoute l'equipement sur la carte
			
			
		}
		
		
		public void supprMur(int x,int y) {
			
			tab[x][y]=" ";
			
		}
		
		
	}
