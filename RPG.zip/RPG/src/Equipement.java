
public class Equipement {
	
	 private int maniabilite;
	 private int impact;
	 private int encombrement;
	 private int solidite;
	 String nom;//les �quipement ont un nom
	 
	 int posX;
	 int posY;
	 String symb="A";
	 
	 
	 public Equipement(){}
	 
	 public Equipement(int encombrement,int solidite,int maniabilite, int impact,String nom){
		 
		 this.maniabilite=maniabilite;
		 this.impact=impact;
		 this.encombrement=encombrement;
		 this.solidite=solidite;
		 this.nom=nom;
		 
	 }
	 public void setNom(String nom) {
		 
		 this.nom=nom;
	 }
	 public void SetPos(int x, int y) {
		 
		 this.posX=x;
		 this.posY=y;
		 
		 
		 
	 }
	 
	 public String getSymb() {
		 
		 return this.symb;
	 }
	 
	 public int getPosX() {
		 
		 return this.posX;
	 }
	
 public int getPosY() {
		 
		 return this.posY;
	 }
	 
	 
	 public int getEncombrement(){

	        return this.encombrement;
	    }

	 public int getSolidite(){
		 
		 	return this.solidite;
	    }
	    
	 public int getManiabilite(){

	        return this.maniabilite;

	    }


	  public int getImpact(){

	        return this.impact;

	    }
	  
	  public void setEncombrement(int encombrement) {
			
			this.encombrement=encombrement;
			
		}
	  
	  public void setManiabilite(int maniabilite) {
			
			this.maniabilite=maniabilite;
		}
	  
	  public void setSolidite(int solidite) {
			
		  this.solidite=solidite;
			
		}
	  
	  public void setImpact(int impact) {
		  
			this.impact=impact;
			
		}
	  
	  
	  public void setPos(int x,int y) {
		  
			this.posX=x;
			this.posY=y;
		}
	  
		
	  
	  public String getNom() {
		  
		  return this.nom;
		  
		  
	  }

}
