import java.util.Scanner;

public class Jeu {

	
	public void initialiserJeu() {
		
		
		System.out.println("Bienvenu dans �L�ANDOR !");
		System.out.println();
		System.out.print("Le but de ce jeu est simple:"+'\n'+"Vous devez vaincre chaque Boss pour parvenir au niveau suivant !");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		for(int i=0;i<8;i++) {
			
			System.out.println();
		}
		
		 System.out.println("Combien de joueur ?");
		int str2 = sc.nextInt();
		
		while(str2!=1 && str2!=2) {
			
			 str2 = sc.nextInt();
		}
		 
		if(str2==1) {
			Joueur a = new Joueur(); 
			a.creerJoueur("1");
			
			Niveau p = new Niveau();//on creer un niveau pour le jeu 
			p.AjouterPerso(a, 0);//on ajoute ce perso a niveau 
			
			for(int i=0;i<8;i++) {
				
				System.out.println();
				this.Niveau1(p,1);
			}
			
		}
			if(str2==2) {
				
				System.out.println("Creation du joueur 1");
				
				Joueur b = new Joueur(); 
				b.creerJoueur("1");
				
				Niveau g = new Niveau();//on creer un niveau pour le jeu 
				g.AjouterPerso(b, 0);//on ajoute ce perso a niveau 
				
				System.out.println("Creation du joueur 2");
				Joueur c = new Joueur(); 
				c.creerJoueur("2");
				g.AjouterPerso(c, 1);
				
				for(int i=0;i<8;i++) {
					
					System.out.println();
					
				}
				
				this.Niveau1(g,2);
		}
			//this.Niveau1(p);//on lance le niveau 1
			
		
		
				
	}
	
	
	public void Niveau1(Niveau a,int k) {
		
		
		a.AjouterCarte();//on ajoute une carte a notre niveau 
		
		//--on ajoute des murs--//
		a.getCarte().addMur(1,10);
		a.getCarte().addMur(2,10);
		a.getCarte().addMur(3,10);
		a.getCarte().addMur(4,10);
		a.getCarte().addMur(5,10);
		a.getCarte().addMur(6,10);
		a.getCarte().addMur(7,10);
		a.getCarte().addMur(8,10);
				
				
		a.getCarte().addMur(16,10);
		a.getCarte().addMur(17,10);
		a.getCarte().addMur(18,10);
		a.getCarte().addMur(19,10);
		a.getCarte().addMur(20,10);
		a.getCarte().addMur(21,10);
		a.getCarte().addMur(22,10);
		a.getCarte().addMur(23,10);
				
				
		a.getCarte().addMur(11, 7);
		a.getCarte().addMur(13, 7);
		a.getCarte().addMur(10, 8);
		a.getCarte().addMur(14, 8);
		a.getCarte().addMur(9,9);
		a.getCarte().addMur(15,9);
		a.getCarte().addMur(9,10);
		a.getCarte().addMur(9,11);
		a.getCarte().addMur(15,11);
		a.getCarte().addMur(10,12);
		a.getCarte().addMur(14,12);
		a.getCarte().addMur(11,13);
		a.getCarte().addMur(13,13);
		
			
		
		a.getCarte().addMur(11,14);
		a.getCarte().addMur(13,14);
		
		a.getCarte().addMur(11,17);
		a.getCarte().addMur(13,17);
		
		a.getCarte().addMur(11,20);
		a.getCarte().addMur(13,20);
		
		a.getCarte().addMur(11,23);
		a.getCarte().addMur(13,23);
		
		a.getCarte().addMur(11,26);
		a.getCarte().addMur(13,26);
		
		a.getCarte().addMur(1,17);
		a.getCarte().addMur(2,17);
		a.getCarte().addMur(23,17);
		a.getCarte().addMur(22,17);
		a.getCarte().addMur(3,18);
		a.getCarte().addMur(21,18);
		a.getCarte().addMur(3,20);
		a.getCarte().addMur(21,20);
		a.getCarte().addMur(1,21);
		a.getCarte().addMur(2,21);
		a.getCarte().addMur(23,21);
		a.getCarte().addMur(22,21);
		
		
		
		for(int i=0;i<4;i++) {
		Monstre q = new Monstre(a.getCarte());
		a.ajouterMob(q);
		}
		
		Armure r=new Armure(15,12,0,0,"Armure de Kalor");
		Boss d=new Boss(3,15,11,8,20,45,12,10,r);//on creer un BOSS
		Marchand z = new Marchand(17,26);
		z.setPos(17, 26);
		
		PotionHeal q = new PotionHeal();
		z.ajoutInventaire(q);
		z.ajoutInventaire(new PotionHeal());
		z.ajoutInventaire(new PotionExplosive());
		
		
		Equipement D= new Arme(0,0,35,35,"Epee Draconique");
		D.SetPos(23,11);	
		a.ajouterMob(d);
		
		a.ajouterMarchand(z);
		
		a.ajouterStuff(D);	
		this.tourDeJeu(a,d,k);	//on lance le tour de jeu 				
		
		niveau2(a.getJoueur2(),k);
		
	}
	
	
	public void niveau2(Joueur[] a,int k) {
		
		Niveau p = new Niveau();
		if(k==1)
			p.AjouterPerso(a[0], 0);
		else {
			p.AjouterPerso(a[0], 0);
			p.AjouterPerso(a[1], 0);
			
		}
			
		
		p.AjouterCarte();//on ajoute une carte a notre niveau 
		Monstre q = new Monstre(p.getCarte());//on cr�er des pnj
		Monstre r =new Monstre(p.getCarte());
		Monstre s = new Monstre(p.getCarte());
		Arme e = new Arme(2,15,0,0,"Baton de Kalidor");
		Boss d=new Boss(4,25,3,12,20,80,12,10,e);//on creer un BOSS
		
		
		
		p.ajouterMob(q);//ajoute les pnj au niveau
		p.ajouterMob(r);
		p.ajouterMob(s);
		
		p.ajouterMob(d);
		if(k==1) {
			p.getCarte().anciennePositionJoueur(a[0]);
			a[0].SetPositionX(5);
			a[0].SetPositionY(28);
			p.getCarte().nouvellePositionJoueur(a[0]);
		}
		
		else {
			
			p.getCarte().anciennePositionJoueur(a[0]);
			a[0].SetPositionX(5);
			a[0].SetPositionY(28);
			p.getCarte().nouvellePositionJoueur(a[0]);
			
			p.getCarte().anciennePositionJoueur(a[1]);
			a[1].SetPositionX(5);
			a[1].SetPositionY(28);
			p.getCarte().nouvellePositionJoueur(a[1]);
		}
		
		this.tourDeJeu(p,d,k);
		
	}
		
	public void tourDeJeu(Niveau a,Boss b,int r) {


		
		

		while(a.getJoueur(0).getPosX()!=12 || a.getJoueur(0).getPosY()!=0) {
			
			

			for(int l=0;l<r;l++) {
				a.getCarte().afficher();
				System.out.println("Tour joueur "+ (l+1));
				this.Affichage(a,l);
			
			a.getCarte().anciennePositionJoueur(a.getJoueur(l));
			a.getJoueur(l).action(a.getCarte());
			a.getCarte().nouvellePositionJoueur(a.getJoueur(l));
			
			for(int k=0;k<a.getMob().size();k++) {
					
				if(!a.getMob2(k).getClass().getSimpleName().equals("Boss")) {
						
					a.getCarte().anciennePositionMob(a.getMob2(k));
					a.getMob2(k).deplacement(a.getCarte(), a.getJoueur(l));
					a.getCarte().nouvellePositionMob(a.getMob2(k));		
				}
			}

			for(int j=0;j<50;j++) {
					
				System.out.println();
			}

			a.getCarte().afficher();//on affiche la carte 
			this.Affichage(a,l);


			for(int i=0;i<a.getMob().size();i++) {
			
				if(posCombat(a,i,l)==true ) {

					a.getJoueur(l).lancementCombat(a,i);

					if(a.getMob2(i).getPV()<=0) {
						
						a.getCarte().anciennePositionMob(a.getMob2(i));
						
						if(b.getPV()<=0 && a.getMob2(i).getClass().getSimpleName().equals("Boss")) {
							a.getCarte().supprMur(12, 0);
					
							((Boss) a.getMob2(i)).getLoot().SetPos(a.getMob2(i).getPosX(),a.getMob2(i).getPosY());	
							
							
							a.ajouterStuff(((Boss) a.getMob2(i)).getLoot());	
							a.getCarte().afficher();
						}
						
						
						 a.getMob().remove(i);
					}

					a.getCarte().nouvellePositionJoueur(a.getJoueur(l));

					for(int j=0;j<50;j++) {
							
						System.out.println();
					}

					a.getCarte().afficher();
				
					}
					
					
					
				}
			
			if(posMarchand(a,l)) {
				a.getMarchand().acheter(a.getJoueur(l));
				
			}
				
				for(int j=0;j<a.getSTUFF().size();j++) {
					if(a.getJoueur(l).getPosY()==a.getSTUFF2(j).getPosY() && a.getJoueur(l).getPosX()==a.getSTUFF2(j).getPosX() ) {
						a.getJoueur(l).ajoutInventaire(a.getSTUFF2(j));
						a.getCarte().retirerObjet(a.getSTUFF2(j));
						a.getSTUFF().remove(j);
						
						
					}
				
					}
				
				
				
				if(a.getJoueur(l).getPV()<=0)
					Mort();
				
				}
			}



	}
	public void Affichage(Niveau a,int l) {//sert � afficher l'�quipement du personnage
		
		System.out.println("Vos Point :"+ a.getJoueur(l).getPoint());
		System.out.println("Vos PV :"+ a.getJoueur(l).getPV());
		System.out.println("");
		System.out.println("Vous �tes �quip� de :");
		System.out.println();
		System.out.println("Votre Armure:"+a.getJoueur(l).getNomArmure());
		System.out.println("Dans votre Main Droite:"+a.getJoueur(l).getNomMainDroite());
		System.out.println("Dans votre Main Gauche:"+a.getJoueur(l).getNomMainGauche());
		System.out.println();
		System.out.println("Dans votre inventaire :");
		for(int i=0;i<a.getJoueur(l).getInventaire().length;i++) {
			
			if(a.getJoueur(l).getInventaire()[i]==null)
				break;
			
			
		System.out.println(a.getJoueur(l).getElmentInvent(i).getNom());
		
		}
		System.out.println("");
 }
	
	
public boolean posMarchand(Niveau a ,int l) {
		
		
		
		if(a.getJoueur(l).getPosY()-1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()-1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()-1==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()-1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()+1==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()-1==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()+1==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()-1==a.getMarchand().getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMarchand().getPosY()&&a.getJoueur(l).getPosX()+1==a.getMarchand().getPosX())
			return true;
		
		
		else
			return false;
		
	}
	
	public boolean posCombat(Niveau a,int b,int l ) {
		
		
		
		if(a.getJoueur(l).getPosY()-1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()-1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()-1==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()-1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()+1==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()-1==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()+1==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()-1==a.getMob2(b).getPosX())
			return true;
		
		else if(a.getJoueur(l).getPosY()+1==a.getMob2(b).getPosY()&&a.getJoueur(l).getPosX()+1==a.getMob2(b).getPosX())
			return true;
		
		
		else
			return false;
		
	}
	
	
	
	public void Mort() {
		
		System.out.println("Vous �tes mort! vous pouvez soit continuer avec une nouvelle vie soit arr�ter");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		while(str.equals("continuer")==false && str.equals("arreter")==false) {
			
			System.out.println("Vous �tes mort! vous pouvez soit continuer avec une nouvelle vie soit arr�ter");
			str = sc.nextLine();
			}
		
		if(str.equals("continuer"))
			this.initialiserJeu();
		
		else if(str.equals("arreter"))
			System.out.println("Vous aurez plus de chance la prochaine fois");
	}
	
	
	public static void main(String[] args) {
	
		Jeu a = new Jeu();
		
		Niveau b = new Niveau();
		
		a.initialiserJeu();
		
		
		
	}
	
	
	
}
