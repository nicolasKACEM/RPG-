import java.util.Scanner;



public class Joueur {

    private int force;
    private int adresse;
    private int resistance;
    private Armure armure ;
    private Equipement inventaire[]=new Equipement[10];
    private Equipement mainDroite = new Equipement();
    private Equipement mainGauche = new Equipement();
    
    private int point=0;
    
    private int PV = 10;

    private int posX;
    private int posY;
    
    private String symb ;

    public Joueur(){}

    public Joueur(int force,int adresse,int resistance, int PV){

        this.force=force;
        this.adresse=adresse;
        this.resistance=resistance;
        this.PV=PV;
        
        this.posX=5;
        this.posY=28;

    }
    
    public void setPV(int a) {
    	
    	this.PV=PV+a;
    }

    public String getNomArmure() {
    	
    	return this.armure.getNom();
    }
    public String getNomMainDroite() {
    	
    	return this.mainDroite.getNom();
    }
    public String getNomMainGauche() {
	
		return this.mainGauche.getNom();
    }
    
    
    
    public void SetMainDroite( Equipement a){

            this.mainDroite=a;

    }
    public void SetMainGauche( Equipement a){

        this.mainGauche=a;

}
    
    public void SetArmure( Armure a){

        this.armure=a;

}
    
    public void SetForce( int a){

        this.force=a;

}
    public void SetAdresse( int a){

        this.adresse=a;

}
    public void SetResistance( int a){

        this.resistance=a;

}
    
    public void SetPositionX( int a){

        this.posX=a;
    }
        
        public void SetPositionY( int a){

            this.posY=a;
        }
        
        public Equipement[] getInventaire() {
        	
        	return this.inventaire;
        }
    

    public int getForce(){

    return this.force;

    }
    
    public int getPosX(){

        return this.posX;

        }
    public int getPosY(){

        return this.posY;

        }
    
    public int getPoint() {
    	
    	return this.point;
    }
    
    public void setPoint(int a) {
    	
    	point+=a;
    }
    public String getSymb(){

        return this.symb;

        }

    public int getAdresse(){

        return this.adresse;

    }

    public int getResistance(){

        return this.resistance;
    }


    public int getPV(){

        return this.PV;
    }

    public void lancementCombat(Niveau a,int b) {
    	
    	System.out.println("Le combat commence!!");
    	Scanner sc = new Scanner(System.in);
		System.out.println("vous pouvez fuir ou commencer le combat :");
		String str = sc.nextLine();
    	
    		while(str.equals("commencer")==false && str.equals("fuir")==false) {
    			
    			 str = sc.nextLine();
    			 System.out.println("vous pouvez fuir ou commencer le combat :");
    			
    		}
    		if(str.equals("commencer")) 
    			combat(a,b);
    		
    		else if(str.equals("fuir")) {
    			
    			if(this.posY+2<29) {
    				if( a.getCarte().posDiffMur(this.posX, this.posY+2)==true ) {
    					System.out.println("vous prennez la fuite");
    					a.getCarte().anciennePositionJoueur(this);
    					this.posY=posY+2;
    				}
    			}
    			else {
    				System.out.println("Il y a un mur derri�re vous !  Vous ne pouvez pas fuir !"  );
    				str = sc.nextLine();
    				combat(a,b);
    			}
    		}
    	
    		
    }

    public int D(int nb){
	
	int mul = 0;
	int tmp = nb;
	
	for(int i = 0;tmp > 0;i++){
		
		tmp = tmp - 3;
		mul = mul +1;
	}
	
	int rest = tmp *(-1);
	
	int n = 0;
	
	if(mul == 0){
		return nb;
	}
	else{
		for(int i=0;i<mul;i++){
			n = n + (int) ((Math.random() * 6 - 1 + 1));
		}
	}
	n = n + rest;
	
	return n;
	
}
    
    
    
    public void objetCombat(Monstre a) {
    	
int z=0;
    	
    	int cpt=0;
    	for(int i=0; inventaire[i]!=null;i++) {
    		
    		if(inventaire[i].getClass().getSimpleName().equals("PotionHeal")) {
    			cpt++;
    			
    		}
    		
    	}
    		
    		System.out.println("Vous �tes �quip� de" + cpt +" potion(s) de vie, voulez vous en utiliser une ?(oui/non)");
    		Scanner sc = new Scanner(System.in);
        	String str = sc.nextLine();
        	
        	if(str.equals("oui")) {

        		for(int j=0; inventaire[j]!=null;j++) {
        			
        			if(inventaire[j].getClass().getSimpleName().equals("PotionHeal")) {
        			
        			((PotionHeal) inventaire[j]).utiliser(this);
        			int k=j;
        			while(j<10) {
        				
        				inventaire[k]=inventaire[k+1];
        				inventaire[k+1]=null;
        				break;
        			}
        			
        			break;
        			}
        			
        			
        		}
        		
        		
        	}
    		
        	if(str.equals("non")) {
        		cpt=0;
        		for(int i=0; inventaire[i]!=null;i++) {
            		
            		if(inventaire[i].getClass().getSimpleName().equals("PotionExplosive")) {
            			cpt++;
            			
            		}
            		
            	}
        		

        		System.out.println("Vous �tes �quip� de" + cpt +" potion(s) explosive(s), voulez vous en utiliser une ?(oui/non)");
        		 str = sc.nextLine();
            	
            	if(str.equals("oui")) {

            		for(int j=0; inventaire[j]!=null;j++) {
            			
            			if(inventaire[j].getClass().getSimpleName().equals("PotionExplosive")) {
            			
            			((PotionExplosive) inventaire[j]).utiliser(a);
            			int k=j;
            			while(j<10) {
            				
            				inventaire[k]=inventaire[k+1];
            				inventaire[k+1]=null;
            				break;
            			}
            			
            			
            			}
            			
            			
            		}
        		
            	}
            	
            	
        	}
    }

    public void combat(Niveau a,int b){

        int init = D(this.adresse) - D(this.armure.getEncombrement());
        int attaque = D(this.adresse) + D(this.mainDroite.getManiabilite()+this.mainGauche.getManiabilite());
        int esquive = D(this.adresse) - D(this.armure.getEncombrement());
        int defense = D(this.resistance) + D(this.armure.getSolidite());
        int degats = D(this.force) + D(this.mainDroite.getImpact()+this.mainGauche.getImpact());

        
        System.out.println("Vous pouvez:");
        System.out.println("-Attaquer");
        System.out.println("-Fuir");
        System.out.println("-Utiliser objet");
        
        Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		while(!str.equals("fuir") && !str.equals("attaquer") && !str.equals("objet")) {
			
			System.out.println("Vous pouvez:");
	        System.out.println("-Attaquer");
	        System.out.println("-Fuir");
	        System.out.println("-Utiliser objet");
	         str = sc.nextLine();
			
		}
		
		if(str.equals("fuir")) {
			if(this.posY+2<29) {
				if( a.getCarte().posDiffMur(this.posX, this.posY+2)==true ) {
					System.out.println("vous prennez la fuite");
					a.getCarte().anciennePositionJoueur(this);
					this.posY=posY+2;
				}
			}
			else {
				System.out.println("Il y a un mur derri�re vous !  Vous ne pouvez pas fuir !"  );
				str = sc.nextLine();
				this.combat(a,b);
				
			}
		}
        
		if(str.equals("objet")) {
			
			objetCombat(a.getMob2(b));
			
			if(a.getMob2(b).getAttaque() > esquive){
	    		   if(a.getMob2(b).getDegats() > defense){
	    			   int dmg = a.getMob2(b).getDegats() - defense;
	    			   System.out.println("Vos d�gats subits:"+degats);
	    			   this.PV = this.PV -dmg;
	    		   }
	    	   }
			
			
			System.out.println("vos PV:"+this.PV);
	        System.out.println("PV ennemie : " + a.getMob2(b).getPV());

	        if(this.PV<=0) {
	            System.out.println("vous etes mort \n");
	        }

	         if(a.getMob2(b).getPV()<=0) {
	            System.out.println("ENNEMIE VAINCU !! \n");
	            recupererPoint(a.getMob2(b));
	       
	            str = sc.nextLine();
	        }
	       
	        if(this.PV>0 && a.getMob2(b).getPV()>0 ) {
	        	
	        		System.out.println("le combat continu \n");
	            	//if(this.actionCombat().equals("continuer")){  
	            		this.combat(a,b);
	            	//}
	            	//else  {
	            		//System.out.println("vous prennez la fuite");
	            		//a.getCarte().anciennePositionJoueur(this);
	            		//this.posY=posY+2;
	            	//}
	            
	        }
		}
        
     /*   System.out.println(init);
        System.out.println(attaque);
        System.out.println(esquive);
        System.out.println(defense);
        System.out.println(degats);*/
        
		if(str.equals("attaquer")) {
      if(init > a.getMob2(b).getInit()){
    	   if(attaque > a.getMob2(b).getEsqu()){
    		   if(degats > a.getMob2(b).getDef()){
    			   int dmg = degats - a.getMob2(b).getDef();
    			   System.out.println("Vos d�gats:"+degats);
    			   a.getMob2(b).setDegats(dmg);
    		   }
    	   }
       
       if(a.getMob2(b).getPV() > 0){
    	  
        	   if(a.getMob2(b).getAttaque() > esquive){
        		   if(a.getMob2(b).getDegats() > defense){
        			   int dmg = a.getMob2(b).getDegats() - defense;
        			   System.out.println("Vos degats subits:"+degats);
        			   this.PV = this.PV -dmg;
        		   }
        	   }
           
       }
      }
       if(init < a.getMob2(b).getInit()){
    	   
    	   
    	   if(a.getMob2(b).getAttaque() > esquive){
    		   if(a.getMob2(b).getDegats() > defense){
    			   int dmg = a.getMob2(b).getDegats() - defense;
    			   System.out.println("Vos degats subits:"+degats);
    			   this.PV = this.PV -dmg;
    		   }
    	   }
    	   
    	   if(this.PV > 0){
    		   if(attaque > a.getMob2(b).getEsqu()){
        		   if(degats > a.getMob2(b).getDef()){
        			   int dmg = degats - a.getMob2(b).getDef();
        			   System.out.println("Vos degats:"+degats);
        			   a.getMob2(b).setDegats(dmg);
        		   }
        	   }
    		   
    		   
    	   }
    	   
       }
        
		
		
		
        System.out.println("vos PV:"+this.PV);
        System.out.println("PV ennemie : " + a.getMob2(b).getPV());

        if(this.PV<=0) {
            System.out.println("vous etes mort \n");
        }

         if(a.getMob2(b).getPV()<=0) {
            System.out.println("ENNEMIE VAINCU !! \n");
            recupererPoint(a.getMob2(b));
            str = sc.nextLine();
        }
       
        if(this.PV>0 && a.getMob2(b).getPV()>0 ) {
        	
        		System.out.println("le combat continu \n");
            	//if(this.actionCombat().equals("continuer")){  
            		this.combat(a,b);
            	//}
            	//else  {
            		//System.out.println("vous prennez la fuite");
            		//a.getCarte().anciennePositionJoueur(this);
            		//this.posY=posY+2;
            	//}
            
        }
        
        }


    }
    
    
    public void recupererPoint(Monstre a) {
    	
    	if(a.getClass().getSimpleName().equals("Monstre"))
    		this.point+=(int)( Math.random()*( 350 - 100 + 1 ) ) + 100;

    	
    	if(a.getClass().getSimpleName().equals("Boss"))
    		this.point+=(int)( Math.random()*( 1500 - 1000 + 1 ) ) + 1000;
    }
    
    public void inventaire() {
    	
    	
    	System.out.println("vous �tes �quip� de: ");
    	for(int i=0; inventaire[i]!=null;i++) {
    		System.out.println(inventaire[i].getNom());
    		
    	}
    	
    	System.out.println("quel objet voulez vous �quiper");
    	
    	Scanner sc = new Scanner(System.in);
    	String str = sc.nextLine();
    	
    	for(int i=0; inventaire[i]!=null;i++) {
    		
    		if(str.equals(inventaire[i].getNom())) {
    			
    			if(inventaire[i].getClass().getSimpleName().equals("Arme")||inventaire[i].getClass().getSimpleName().equals("Equipement")) {
    				
    				System.out.println("dans quel main voulez vous l'equiper");
    				 str = sc.nextLine();
    				if(str.equals("droite")) {
    					
    					Equipement z = new Equipement();
    					
    					z=mainDroite;
    					mainDroite=inventaire[i];
    					inventaire[i]=z;
    				}
    				if(str.equals("gauche")) {
    					
    					Equipement z = new Equipement();
    					
    					z=mainGauche;
    					mainGauche=inventaire[i];
    					inventaire[i]=z;
    					
    					
    				}
    				
    			}
    				
    				if(inventaire[i].getClass().getSimpleName().equals("Armure")) {
    					
    					Armure z = new Armure();
    					
    					z=armure;
    					armure=(Armure) inventaire[i];
    					inventaire[i]=z;
    				}
    				
    			
    			
    		}
    	}
    	
    }
    
    
    public void objet() {
    	 int z=0;
    	
    	int cpt=0;
    	for(int i=0; inventaire[i]!=null;i++) {
    		
    		if(inventaire[i].getClass().getSimpleName().equals("PotionHeal")) {
    			cpt++;
    			
    		}
    		
    	}
    		
    		System.out.println("Vous �tes �quip� de" + cpt +" potion(s) de vie, voulez vous en utiliser une ?(oui/non)");
    		Scanner sc = new Scanner(System.in);
        	String str = sc.nextLine();
        	
        	if(str.equals("oui")) {

        		for(int j=0; inventaire[j]!=null;j++) {
        			
        			if(inventaire[j].getClass().getSimpleName().equals("PotionHeal")) {
        			
        			((PotionHeal) inventaire[j]).utiliser(this);
        			int k=j;
        			while(j<10) {
        				
        				inventaire[k]=inventaire[k+1];
        				inventaire[k+1]=null;
        				break;
        			}
        			
        			break;
        			}
        			
        			
        		}
        		
        		
        	}
    		
    	
    	
    	
    }
    
    
    public void action (Carte a) {
    	
    	System.out.println("vous pouvez:");
    	
    	System.out.println("-Utiliser objet(objet)");
    	System.out.println("-Utiliser inventaire(inventaire)");
    	
    	System.out.println("-Avancer � droite,gauche,avant,arriere(z,q,s,d)");
    	Scanner sc = new Scanner(System.in);
    	String str = sc.nextLine();
    	
    	
    	
    	if(str.equals("objet"))
    		objet();
    	
    	if(str.equals("inventaire"))
    		inventaire();
    	
    	
    	if(str.equals("d")&& a.posDiffMur(posX+1, posY)&&a.posDiffMonstre(posX+1, posY)==true)
    		this.posX=posX + 1 ;
    	
    	
    	if(str.equals("q")&& a.posDiffMur(posX-1, posY)&&a.posDiffMonstre(posX-1, posY)==true)
    		this.posX=posX - 1;
    	
    	
    	if(str.equals("z")&& a.posDiffMur(posX, posY-1)&&a.posDiffMonstre(posX, posY+1)==true)
    		this.posY=posY -1;
    	
    	
    	if(str.equals("s")&& a.posDiffMur(posX, posY+1)&&a.posDiffMonstre(posX, posY-1)==true)
    		this.posY=posY+1;
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
    
    	public String actionCombat(){
    		
    		
    		
    		Scanner sc = new Scanner(System.in);
    		System.out.println("vous pouvez fuir ou continuer :");
    		String str = sc.nextLine();
    		
    		return str;
    			
    	}
    	
    	
    	
    	public Joueur creerJoueur(String f) {
    		
    		Joueur a = new Joueur();
    			
    		/*while(a.getForce() + a.getAdresse() + a.getResistance() != 18) {
    			System.out.println("repartissez vos 18 points d'attributs !!");
    			System.out.println("combien de ponit pour la force ?");
    			Scanner sc = new Scanner(System.in);
    			int str = sc.nextInt();
    			
    			a.SetForce(str);
    			
    			System.out.println("combien de ponit pour l'Adresse(il vous en reste " + (18-a.getForce()) + ") ?");
    			str =sc.nextInt();
    			a.SetAdresse(str);
    			
    			System.out.println("combien de ponit pour la reistance (il vous en reste " + (18-(a.getForce()+a.getAdresse())) + ") ?");
    			str =sc.nextInt();
    			a.SetResistance(str);
    			
    		}
    		
    		this.posX=5;
    		this.posY=28;*/
    		
    		System.out.println("Il existe diff�rentes classes pour ce jeu !");
    		System.out.println("Vous pouvez �tre: Guerrier(DPS/TANK), Assassin(DPS),Paladin(TANK), Mendiant(??) ");
    		Scanner sc = new Scanner(System.in);
        	String str = sc.nextLine();
        	
        	while(!str.equals("Guerrier")&&!str.equals("guerrier")&&!str.equals("Assassin")&&!str.equals("assassin")&&!str.equals("Paladin")&&!str.equals("paladin")&&!str.equals("Mendiant")&&!str.equals("mendiant")) {
        		
        		str = sc.nextLine();
        		
        	}
        	
        	if(str.equals("Guerrier")||str.equals("guerrier")) {
        		
        		this.SetForce(8);
        		this.SetResistance(7);
        		this.SetAdresse(3);
        		this.PV=19;
        		this.mainDroite = new Arme(6,3,0,0,"Epee de de Guerrier"); 
        		this.mainGauche = new Equipement(8,2,5,3,"Bouclier de Guerrier");
        		this.armure = new Armure(5,15,0,0,"Armure de Guerrier");
        		this.inventaire[0]=new PotionHeal();
        		this.inventaire[1]=new PotionHeal();
        		
        		this.symb=f;
        	}
        	
        	if(str.equals("Assassin")||str.equals("assassin")) {
        		
        		this.SetForce(6);
        		this.SetResistance(4);
        		this.SetAdresse(8);
        		this.PV=17;
        		
        		this.mainDroite = new Arme(8,5,0,0,"Lame d'Assassin"); 
        		this.mainGauche = new Arme(8,5,0,0,"Lame d'Assassin");
        		this.armure = new Armure(2,5,0,0,"Tenu d'Assassin");
        		this.inventaire[0]=new PotionHeal();
        		this.inventaire[1]=new PotionExplosive();
        		this.symb=f;
        		
        	}
        	
        	if(str.equals("Paladin")||str.equals("paladin")) {
        		
        		this.SetForce(7);
        		this.SetResistance(8);
        		this.SetAdresse(3);
        		this.PV=22;
        		
        		this.mainDroite = new Arme(3,6,0,0,"Marteau de Paladin"); 
        		this.mainGauche = new Armure(2,2,0,0," rien ");
        		this.armure = new Armure(7,7,0,0,"Tenu de Paladin");
        		this.inventaire[1]=new PotionHeal();
        		this.inventaire[0]=new PotionHeal();
        		this.symb=f;
        		
        	}
    		
        	if(str.equals("Mendiant")||str.equals("mendiant")) {
        		
        		while(a.getForce() + a.getAdresse() + a.getResistance() != 18) {
        			System.out.println("repartissez vos 18 points d'attributs !!");
        			System.out.println("combien de point pour la force ?");
        			Scanner sc2 = new Scanner(System.in);
        			int str2 = sc.nextInt();
        			
        			a.SetForce(str2);
        			
        			System.out.println("combien de point pour l'Adresse(il vous en reste " + (18-a.getForce()) + ") ?");
        			str2 =sc.nextInt();
        			a.SetAdresse(str2);
        			
        			System.out.println("combien de point pour la resistance (il vous en reste " + (18-(a.getForce()+a.getAdresse())) + ") ?");
        			str2 =sc2.nextInt();
        			a.SetResistance(str2);
        			
        			this.PV=(int)( Math.random()*( 20 - 1 + 8 ) ) + 8;
        			
        		}
        		
        		this.mainDroite = new Arme(4,6,0,0,"rien"); 
        		this.mainGauche = new Arme(4,6,0,0,"rien");
        		this.armure = new Armure(3,3,0,0,"pagne");
        		this.inventaire[0]=new PotionHeal();
        		this.symb=f;
        	}
    		
        	this.posX=5;
    		this.posY=28;
    		
    		return a;
    		
    	}

    	
    	public void ajoutInventaire(Equipement a) {
    		int z=0;
    		if(inventaire[9]!=null) {
    			System.out.println("Vous devez vous s�parer d'un objet");
    			for(int j=0; j<10;j++) {
    	    		System.out.println(inventaire[j].getNom());
    	    		
    	    	}
    			Scanner sc = new Scanner(System.in);
    			String str = sc.nextLine();
    			for(int j=0; j<10;j++) {
    	    		if(str.equals(inventaire[j].getClass().getSimpleName())) {
    	    			z=j;
    	    			inventaire[j]=null;
    	    			while(z<10) {
    	    				inventaire[z]=inventaire[z+1];
    	    			}
    	    			
    	    		}
    	    		
    	    	}
    		}
    		
    		
    		for(int i=0;i<inventaire.length;i++) {
    			
    			if(inventaire[i]==null) {
    				this.inventaire[i]=a;
    				break;
    			}
    			
    		}
   	}
   
    public Equipement getElmentInvent(int pos) {
    	
    	return inventaire[pos];
    }
}