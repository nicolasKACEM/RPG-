import java.util.Scanner;

public class Marchand extends PNJ  {
	
	private int posX;
	private int posY;

	private Equipement inventaire[] = new Equipement[10]; 
	
	
	public Marchand(int x,int y) {
		
		super("�");
		posX=x;
		posY=y;
	}
	
	public void setPos(int x,int y) {
		
		posX=x;
		posY=y;
		
	}
	
	public int getPosX() {
		
		return this.posX;
	}
	
	public int getPosY() {
		
		return this.posY;
	}
	
	public void ajoutInventaire(Equipement a) {
		
		
		
		for(int i=0;i<inventaire.length;i++) {
			
			if(inventaire[i]==null) {
				this.inventaire[i]=a;
				break;
			}
			
		}
	}
	
	
	public void acheter(Joueur a) {
		
		System.out.println("Vous pouvez acheter des objets chez le marchand, voulez vous acheter quelque chose ?");
		Scanner sc = new Scanner(System.in);
    	String str = sc.nextLine();
    	
    	if(str.equals("oui")) {
    		
    		System.out.println("En stock:");
    		for(int i=0;inventaire[i]!=null;i++) {
    			
    			System.out.println(inventaire[i].getNom());
    		
    		}
    		
    		str = sc.nextLine();
    		if(str.equals("potion de vie")) {
    			if(a.getPoint()-150>=0) {
    				a.setPoint(-150);
    				a.ajoutInventaire(new PotionHeal());
    				for(int i=0;inventaire[i]!=null;i++) {
    				
    					if(inventaire[i].getClass().getSimpleName().equals("PotionHeal")) {
    						int k=i;
    	        			while(i<10) {
    	        				
    	        				inventaire[k]=inventaire[k+1];
    	        				inventaire[k+1]=null;
    	        				break;
    	        			}
    					}	
    					
    				}
    			}
    			
    			else {
    				
    			System.out.println("Pas assez de point !");
    			str = sc.nextLine();
    			}
    		}
    		
    		if(str.equals("potion explosive")) {
    			
    			if(a.getPoint()-150>=0) {
    				a.setPoint(-150);
    				a.ajoutInventaire(new PotionExplosive());
    				for(int i=0;inventaire[i]!=null;i++) {
    				
    					if(inventaire[i].getClass().getSimpleName().equals("PotionExplosive")) {
    						int k=i;
    	        			while(i<10) {
    	        				
    	        				inventaire[k]=inventaire[k+1];
    	        				inventaire[k+1]=null;
    	        				break;
    	        			}
    					}
    					
    				}
    			}
    			
    			else {
    				
    				System.out.println("Pas assez de point !");
    				str = sc.nextLine();
    			}
    		}
    		
    	}
		
		
	}
	
}
