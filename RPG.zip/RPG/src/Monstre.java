

public class Monstre extends PNJ{
	
	private int initiative;
	    private int attaque;
	    private int esquive;
	    private int defense;
	    private int degats;


	    private int PV;
	    
	    
	    private int posX;
	    private int posY;
	    
	   

	   public Monstre(int initiative, int attaque,int esquive,int defense, int degats, int PV, int posX,int posY,String symb) {
		   
		   super(symb);
		   
		   this.initiative=initiative;
		   this.attaque=attaque;
		   this.esquive=esquive;
		   this.defense=defense;
		   this.degats=degats;
		   this.PV=PV;
		   this.posX=posX;
		   this.posY=posY;
		   
		   
		   
		   
	   }

	    public Monstre(Carte a){

	    	
	    	super("M");
	        this.initiative=(int)( Math.random()*( 10 - 1 + 1 ) ) + 1;
	        this.attaque=(int)( Math.random()*( 25 - 1 + 1 ) ) + 1;
	        this.esquive=(int)( Math.random()*( 15 - 1 + 1 ) ) + 1;
	        this.defense=(int)( Math.random()*( 15 - 1 + 1 ) ) + 1;
	        this.degats=(int)( Math.random()*( 14 - 1 + 1 ) ) + 1;
	        this.PV = (int)( Math.random()*( 20 - 1 + 1 ) ) + 1;
	        while(this.posX==0 || this.posX==14 || this.posY==0 || this.posY==29 || !a.posDiffMur(posX, posY) || this.posY>25 || !a.posDiffMonstre(posX, posY)) {
	        this.posX=(int)( Math.random()*( 14 - 0 + 1 ) ) + 0;
	        this.posY=(int)( Math.random()*( 29 - 0 + 1 ) ) + 0;
	       
	        
	        }
	    }
	    
	    
	    
	    public int getPosX() {
	    	
	    	return this.posX;
	    }
	    
	    public int getPosY() {
	    	
	    	
	    	return this.posY;
	    }

	        public int getInit(){

	            return this.initiative;
	        }


	         public int getAttaque(){

	            return this.attaque;
	        }
	         public int getDef(){

	            return this.defense;
	        }
	         public int getEsqu(){

	            return this.esquive;
	        }
	         public int getDegats(){

	            return this.degats;
	        }

	        public int getPV(){

	            return this.PV;
	        }

	        public void setDegats(int pv){
	        		
	            this.PV=this.PV-pv;

	    }
	        
	       
	        public void deplacement(Carte a,Joueur b) {
	        	
	        	if(b.getPosX()>this.posX && a.posDiffMur(posX+1, posY) && a.posDiffMonstre(posX+1, posY) &&(posX+1!=b.getPosX() && posY!=b.getPosY()) )
	        		this.posX+=1;
	        	
	        	else if(b.getPosX()<this.posX && a.posDiffMur(posX-1, posY)  && a.posDiffMonstre(posX-1, posY)&&(posX-1!=b.getPosX() && posY!=b.getPosY()))
	        		this.posX-=1;
	        	
	        	else if(b.getPosY()>this.posX && a.posDiffMur(posX, posY+1) && a.posDiffMonstre(posX, posY+1) &&(posX!=b.getPosX() && posY+1!=b.getPosY()) )
	        		this.posY+=1;
	        	
	        	else if(b.getPosX()<this.posX && a.posDiffMur(posX, posY-1) && a.posDiffMonstre(posX, posY-1) &&(posX!=b.getPosX() && posY-1!=b.getPosY()) )
	        		this.posY-=1;
	        	
	        }
	        

}
