import java.util.ArrayList;

public class Niveau {
	
	private Joueur tab[] = new Joueur[2];
	
	private ArrayList<Monstre> mob = new ArrayList<Monstre>();
	
	private ArrayList<Equipement> stuff = new ArrayList<Equipement>();
	
	private Carte a = new Carte();
	
	private Marchand z ;
	
	public Joueur getJoueur(int pos) {
		
		
		return this.tab[pos];
	}
	
	public Carte getCarte() {
		
		return this.a; 
	
	}
	
	public ArrayList getMob() {
		
		
		return this.mob;
		
	}
	public Joueur[] getJoueur2() {
		
		
		return this.tab;
		
	}
	
	public ArrayList getSTUFF() {
		
		
		return this.stuff;
		
	}
	
	public Equipement getSTUFF2(int pos) {
		
		
		return stuff.get(pos);
		
	}

	public Marchand getMarchand() {
	
		return this.z;
	}

	public Monstre getMob2(int pos) {
		
		
		return mob.get(pos);
		
	}

	public void AjouterPerso(Joueur a, int pos) {
		
		
		
		tab[pos]=a;
		
		
	}
	
	public void AjouterCarte() {
		
		this.a.CreerCarte();
		this.a.nouvellePositionJoueur(this.tab[0]);
		
		
		
	}
	
	
	public void ajouterStuff(Equipement a ) {
		
		stuff.add(a);
		this.a.ajouterStuff(a);
		
		
	}
	
	public void ajouterMob(Monstre a) {
		
		mob.add(a);
		this.a.ajouterMob(a);
		
		}
	
public void ajouterMarchand(Marchand a) {
		
		z=a;
		this.a.ajouterMarchand(a);
		
		}
	
	
	
	

}
