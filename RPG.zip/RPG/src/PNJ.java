


	
public class PNJ {
	
	private String symb;
		
		
		
	public PNJ(String symb) {
			
		this.symb=symb;
			
			
	}

	
	public String getSymb() {
	    	
    	return this.symb;
    
	}
		

	}

