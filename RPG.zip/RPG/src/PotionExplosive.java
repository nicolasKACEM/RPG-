

public class PotionExplosive extends Equipement {
	
	
	public PotionExplosive() {
		
		super(0,0,0,0,"Potion Explosive");

		
	}
	
	public void utiliser(Monstre a) {
		
		a.setDegats(4);
		
	}

}
