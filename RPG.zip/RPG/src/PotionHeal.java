

public class PotionHeal extends Equipement{

	
	
	public PotionHeal() {
		
		super(0,0,0,0,"Potion de vie");
	}
	
	
	public void utiliser(Joueur a) {
		
		a.setPV(8);
		
	}
	
}
